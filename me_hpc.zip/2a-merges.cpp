#include <iostream>
#include <omp.h>
#include <chrono>

using namespace std;
using namespace std::chrono;
// Function declarations
void mergesort(int a[], int i, int j);
void merge(int a[], int i1, int j1, int i2, int j2); // merges two sorted portions

void mergesort(int a[], int i, int j)
{
    int mid;
    if (i < j)
    {
        mid = (i + j) / 2;
        // Divide the array into two halves and sort each half recursively in parallel
#pragma omp parallel sections
        {
#pragma omp section
            {
                mergesort(a, i, mid);
            }
#pragma omp section
            {
                mergesort(a, mid + 1, j); // Recursively sort the right half
            }
        }
        merge(a, i, mid, mid + 1, j); // Merge the sorted halves
    }
}

// Merge function to merge two sorted arrays
void merge(int a[], int i1, int j1, int i2, int j2)
{
    int temp[1000]; // Temporary array to store merged result
    int i, j, k;
    i = i1;
    j = i2;
    k = 0;

    cout << "\nMerging: ";
    for (int x = i1; x <= j1; x++) // Displaying the first half of the array
    {
        cout << a[x] << " ";
    }
    cout << "and ";
    for (int x = i2; x <= j2; x++) // Displaying the second half of the array
    {
        cout << a[x] << " ";
    }
    cout << endl;

    // Merging two sorted arrays
    while (i <= j1 && j <= j2)
    {
        if (a[i] < a[j])
        {
            temp[k++] = a[i++];
        }
        else
        {
            temp[k++] = a[j++];
        }
    }
    // Copy the remaining elements of the first part
    while (i <= j1)
    {
        temp[k++] = a[i++];
    }
    // Copy the remaining elements of the second part
    while (j <= j2)
    {
        temp[k++] = a[j++];
    }
    for (i = i1, j = 0; i <= j2; i++, j++) // Copying merged elements back to original array
    {
        a[i] = temp[j];
    }

    cout << "Result after merging: ";
    for (int x = i1; x <= j2; x++)
    {
        cout << a[x] << " ";
    }
    cout << endl;
}

int main()
{
    int *a, n, i;
    cout << "\nEnter size of Array : ";
    cin >> n;
    a = new int[n];
    cout << "\nEnter elements : \n";
    for (i = 0; i < n; i++)
    {
        cin >> a[i];
    }

    auto start = high_resolution_clock::now();
    mergesort(a, 0, n - 1); // Call merge sort function array, start index, last indexs
    auto stop = high_resolution_clock::now();
    auto result = stop - start;
    auto duration = duration_cast<nanoseconds>(result);
    cout << "Time required by sequential merge sort: " << duration.count() << " ns\n";
    cout << "Sorted array: ";
    for (i = 0; i < n; i++)
    {
        cout << a[i] << " ";
    }
    cout << endl;

    auto start1 = high_resolution_clock::now();
#pragma omp parallel sections
    {
#pragma omp section
        {
            mergesort(a, 0, n - 1);
        }
    }
    auto stop1 = high_resolution_clock::now();
    auto result1 = stop1 - start1;
    auto duration1 = duration_cast<nanoseconds>(result1);
    cout << "Time required by parallel merge sort: " << duration1.count() << " ns\n";
    cout << "Sorted array: ";
    for (i = 0; i < n; i++)
    {
        cout << a[i] << " ";
    }
    cout << endl;

    delete[] a; // Free dynamically allocated memory
    return 0;
}
