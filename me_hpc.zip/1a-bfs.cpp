#include <bits/stdc++.h>
using namespace std;

int nodes;
int adj_mat[20][20]; // to represent graph
int visited_s[20];   // array track visited nodes
int visited_p[20];

void s_BFS(int s)
{
    queue<int> q; // initiating queue
    q.push(s);
    visited_s[s] = 1; // marking source node as visited

    while (!q.empty())
    {
        int n = q.front();
        cout << n << " ";
        q.pop(); // Remove front element from queue

        // Iterate through all nodes adjacent to 'n'
        for (int i = 0; i < nodes; i++)
        {
            // If there is a connection from 'n' to 'i' and 'i' is not visited
            if (adj_mat[n][i] && !visited_s[i])
            {
                visited_s[i] = 1; // Mark 'i' as visited

                q.push(i); // Push 'i' into the queue
            }
        }
    }
}

void p_BFS(int s) // function for BFS traversal
{

    queue<int> q;
    q.push(s);
    visited_p[s] = 1; // marking source node as visited

    while (!q.empty())
    {
        int n = q.front();
        q.pop();

#pragma omp parallel for
        for (int i = 0; i < nodes; i++)
        {
            if (adj_mat[n][i] && !visited_p[i])
            {
                visited_p[i] = 1;
                q.push(i);
            }
        }
    }
}

int main()
{
    cout << "Enter the number of nodes: ";
    cin >> nodes;
    // Input the adjacency matrix
    for (int i = 0; i < nodes; i++)
    {
        for (int j = 0; j < nodes; j++)
        {
            char edge;
            cout << "\nIs there any route from " << i << " to " << j << " (Enter: y/n) : ";
            cin >> edge;

            if (edge == 'y')
            {
                adj_mat[i][j] = 1; // If there is route set adjacency matrix value 1
            }
            else if (edge == 'n')
            {
                adj_mat[i][j] = 0;
            }
        }
    }

    cout << "The BFS traveral for the graph is: ";
    auto start = chrono::high_resolution_clock::now();
    s_BFS(0);
    auto stop = chrono::high_resolution_clock::now();
    auto result = stop - start;
    auto duration = chrono::duration_cast<chrono::nanoseconds>(result);
    cout << "\nTime taken by sequential BFS: " << duration.count() << " nanoseconds";

    auto start2 = chrono::high_resolution_clock::now();
#pragma omp parallel num_threads(4)
    {
#pragma omp single
        {
            p_BFS(0);
        }
    }
    auto stop2 = chrono::high_resolution_clock::now();
    auto result2 = stop2 - start2;
    auto duration2 = chrono::duration_cast<chrono::nanoseconds>(result2);
    cout << "\nTime taken by parallel BFS: " << duration2.count() << " nanoseconds";
    return 0;
}