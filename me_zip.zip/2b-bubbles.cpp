#include <bits/stdc++.h>
using namespace std;
using namespace std::chrono;
void bubblesort_s(int arr[], int n)
{
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = 0; j < n - i - 1; j++)
        {
            if (arr[j] > arr[j + 1])
            {
                swap(arr[j], arr[j + 1]); // Swapping adjacent elements if they are in the wrong order
            }
        }
    }
}
void bubblesort_p(int arr[], int n)
{
    for (int i = 0; i < n - 1; ++i)
    {
#pragma omp parallel for
        for (int j = 0; j < n - i - 1; ++j)
        {
            if (arr[j] > arr[j + 1])
            {
                swap(arr[j], arr[j + 1]);
            }
        }
    }
}

// Function to display array elements
void showArray(int arr[], int n)
{
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " "; // Printing each element of the array
    }
    cout << endl;
}

int main()
{
    int size;
    cout << "Enter the size of the array: ";
    cin >> size;

    int arr_s[size];
    int arr_p[size];

    cout << "Enter " << size << "intergers of the array: \n";
    for (int i = 0; i < size; i++)
    {
        cin >> arr_s[i];
        arr_p[i] = arr_s[i]; // Copying elements to parallel array
    }

    cout << "Unsorted array: ";
    showArray(arr_s, size); // Displaying unsorted array

    auto start = high_resolution_clock::now();
    bubblesort_s(arr_s, size);
    auto stop = high_resolution_clock::now();
    auto result = stop - start;
    auto duration = duration_cast<nanoseconds>(result);
    cout << "Time req by seq is: " << duration.count() << "ns\n";
    cout << "Sorted array: ";
    showArray(arr_s, size);

    auto start1 = high_resolution_clock::now();
#pragma omp parallel num_threads(4)
    {
        bubblesort_p(arr_p, size);
    }
    auto stop1 = high_resolution_clock::now();
    auto result1 = stop1 - start1;
    auto duration1 = duration_cast<nanoseconds>(result1);
    cout << "Time req by parallel is: " << duration1.count() << "ns\n";
    cout << "Sorted array: ";
    showArray(arr_p, size);

    return 0;
}